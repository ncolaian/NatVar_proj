#This will perform an analysis on the peptides that could increase plant growth in arabidopsis

library(tidyr)
library(ggplot2)
library(dplyr)

full_sgi <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/sgi_data/sgi_increase_nat_variants_formatted_4_25_19.csv")
full_sgi <- rbind(full_sgi,read.csv("/Users/nicholascolaianni/Documents/dangl_lab/sgi_data/sgi_increase_5_9_19_rep2.csv") )
full_sgi <- gather(full_sgi, "plate_col", "mg", A:L, na.rm = T)
full_sgi$mg <- full_sgi$mg/10
full_sgi$Plate <- as.factor(full_sgi$Plate)
full_sgi$Peptide_use <- relevel(full_sgi$Peptide_use, ref = "None")
full_sgi$Condition <- relevel(full_sgi$Condition, ref="fls2efr")
full_sgi$Rep <- as.factor(full_sgi$Rep)

ggplot(full_sgi, aes(Condition, mg, color=Peptide_use))+
  geom_boxplot()+
  facet_wrap(facets = "Plate", scales="free_x")
ggplot(full_sgi, aes(Peptide_use, mg, color=Condition))+
  geom_boxplot()+
  facet_wrap(facets = "Rep", scales="free_x")

#go through each plate and adjust accordingly
#going to create a model first
library(lme4)
library(lmerTest)
linear_model <- lm(mg ~ Peptide_use * Condition + Rep, data = full_sgi)
summary(linear_model)

#use only the data from the same plates
linear_model <- lm(mg ~ Peptide_use * Condition, data = full_sgi[full_sgi$Plate %in% c(5,12),])
summary(linear_model)

#Going to use z-score on the control for each plate
z_score_data <- c()
for ( i in unique(full_sgi$Plate )) {
  col_m <- mean(full_sgi$mg[full_sgi$Plate == i & full_sgi$Condition == "col" & full_sgi$Peptide_use == "None"])
  col_s <- sd(full_sgi$mg[full_sgi$Plate == i & full_sgi$Condition == "col" & full_sgi$Peptide_use == "None"])
  fls2_m <- mean(full_sgi$mg[full_sgi$Plate == i & full_sgi$Condition == "fls2efr" & full_sgi$Peptide_use == "None"])
  fls2_s <- sd(full_sgi$mg[full_sgi$Plate == i & full_sgi$Condition == "fls2efr" & full_sgi$Peptide_use == "None"])
  
  fls2_z <- (full_sgi$mg[full_sgi$Plate == i & full_sgi$Condition == "fls2efr" & full_sgi$Peptide_use != "None"]-fls2_m)/fls2_s
  col_z <- (full_sgi$mg[full_sgi$Plate == i & full_sgi$Condition == "col" & full_sgi$Peptide_use != "None"]-col_m)/col_s
  c_non_z <- (full_sgi$mg[full_sgi$Plate == i & full_sgi$Condition == "col" & full_sgi$Peptide_use == "None"]-col_m)/col_s
  fls2_non_z <- (full_sgi$mg[full_sgi$Plate == i & full_sgi$Condition == "fls2efr" & full_sgi$Peptide_use == "None"]-fls2_m)/fls2_s
  pep <- unique(as.character(full_sgi$Peptide_use[full_sgi$Plate == i & full_sgi$Condition == "col" & full_sgi$Peptide_use != "None"]))
  #append plate, peptide, condition, and z-score for both fls2 and col
  for ( j in 1:length(fls2_z)){
    z_score_data <- append(z_score_data, c(i, pep, "col", col_z[j], i, pep, "fls2efr", fls2_z[j]
    ))
  }
  for ( j in 1:length(fls2_non_z)){
    z_score_data <- append(z_score_data, c(i, "None", "col", col_z[j], i, "None", "fls2efr", fls2_z[j]
    ))
  }
}
z_score_data <- as.data.frame(matrix(z_score_data, ncol = 4, byrow = T))
z_score_data$V4 <- as.numeric(as.character(z_score_data$V4))

ggplot(z_score_data, aes(V2, V4, color=V3))+
  geom_boxplot(outlier.colour = NA)+
  labs(y="Control Z-Score", x="Peptide", color="Condition")

z_score_data$V2 <- relevel(z_score_data$V2, ref="None")
z_score_data$V3 <- relevel(z_score_data$V3, ref="fls2efr")
linear_model <- lm(V4 ~ V2 * V3, data = z_score_data)
summary(linear_model)
anova(linear_model)
linear_model <- lm(V4 ~ V3, data = z_score_data[z_score_data$V2=="361",])
summary(linear_model)

data1="pa_test_07-11-20-182512_0_1_3_5_10_50_100_1.txt"

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/flg22_check-inoc -r $data1 -n 182512 -s 182512_names.txt -tr -pn 1
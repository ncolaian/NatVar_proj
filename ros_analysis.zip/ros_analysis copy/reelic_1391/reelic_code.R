#this script will be to analyze the re-elicitation ROS data

library(ggplot2)
library(tidyr)
library(Bolstad2)

#early timepoint
early <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/124342.summary_info.csv",stringsAsFactors = F)
#later timepoint
late <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/135921.summary_info.csv" ,stringsAsFactors = F)

plot <- ggplot(late, aes(x=Time, y=measurement, color=Name))+
  geom_line(size=1.5)+
  #  geom_errorbar(aes(ymin=measurement-sd, ymax=measurement+sd))+
  ylab("Photocount")+
  xlab("Seconds")+
  theme(text = element_text(size=20))+
  labs(color='Peptide') 



late$Time <- late$Time + (max(early$Time)+600)
late$measurement <-late$measurement - min(late$measurement)
early$measurement <- early$measurement - min(early$measurement)

combined <- rbind(early, late)

pallete <- scale_color_brewer()

ggplot(combined, aes(x=Time/60, y=measurement, color=Name))+
  geom_line(size=1.5)+
  geom_errorbar(aes(ymin=measurement-se, ymax=measurement+se))+
  ylab("Photocount")+
  xlab("Minutes")+
  theme(text = element_text(size=20))+
  labs(color='Peptide') +
  geom_vline(aes(xintercept=60))+
  #scale_y_log10()+
  scale_color_brewer(palette = "Set1")+
  theme_classic()+
  scale_x_continuous(breaks=c(0,6,15,30,40,50,60, 66, 75, 90, 100, 110))


#Trial 2
early <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/155325.summary_info.csv",stringsAsFactors = F)
#later timepoint
late <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/170721.summary_info.csv" ,stringsAsFactors = F)

plot <- ggplot(late, aes(x=Time, y=measurement, color=Name))+
  geom_line(size=1.5)+
  #  geom_errorbar(aes(ymin=measurement-sd, ymax=measurement+sd))+
  ylab("Photocount")+
  xlab("Seconds")+
  theme(text = element_text(size=20))+
  labs(color='Peptide') 


late$Time <- late$Time + (max(early$Time)+600)
late$measurement <-late$measurement - min(late$measurement)
early$measurement <- early$measurement - min(early$measurement)

combined <- rbind(early, late)

pallete <- scale_color_brewer()

ggplot(combined, aes(x=Time/60, y=measurement, color=Name))+
  geom_line(size=1.5)+
  geom_errorbar(aes(ymin=measurement-se, ymax=measurement+se))+
  ylab("Photocount")+
  xlab("Minutes")+
  theme(text = element_text(size=20))+
  labs(color='Peptide') +
  geom_vline(aes(xintercept=60))+
  #scale_y_log10()+
  scale_color_brewer(palette = "Set1")+
  theme_classic()+
  scale_x_continuous(breaks=c(0,6,13,16,26,30,40,50,60, 66, 73, 76,86, 90, 100, 110))

combined <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/antag_12_16_19/132351.auc_data.csv" ,stringsAsFactors = F)
box_auc <- ggplot(combined, aes(x=Name, y=AUC))+
  geom_point()+
  geom_boxplot()+
  theme(text = element_text(size=20))+
  stat_compare_means(method = "t.test",label = "p.signif", ref.group = "Pta", label.y = max(combined$AUC)+sd(combined$AUC))
box_auc
data1="reelic_1_03-24-20-171338_w+w_w+100-22_1-22+100-22_1391+22_20+22.txt"
data2="reelic_2_03-24-20-191350_w+w_w+100-22_1-22+100-22_1391+22_20+22.txt"
data3="reelic_2_03-24-20-191351.txt"
data4="reelic_pre_1_03-24-20-161700.txt"
data5="1391_endo_post1_08-11-20-135921_pa22x4_m.txt"
data6="1391_endo_post2_08-11-20-170721.txt"
data7="1391_endo_pre1_08-11-20-124342_m_20_22_1391_m.txt"
data8="1391_endo_pre1_08-11-20-155325_m_20_22_1391_m.txt"

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/ -r $data1 -n 171338 -s 171338_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/ -r $data2 -n 191350 -s 191350_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/ -r $data3 -n 191351 -s 191351_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/ -r $data4 -n 161700 -s 161700_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/ -r $data5 -n 135921 -s 135921_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/ -r $data6 -n 170721 -s 170721_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/ -r $data7 -n 124342 -s 124342_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/reelic_1391/ -r $data8 -n 155325 -s 155325_names.txt -tr -pn 1
data1="priming_bak1_06-16-20-164747_cdw_fe_bak_dwx3_1uM1949x3.txt"
data2="priming_bak1_2nd_06-16-20-180916_c_fe_bak_dw_1uM1949_5nMflg22.txt"
data3="priming_bak1_2nd_post_06-16-20-190520_c_fe_bak.txt"
data4="priming_bak1_3rd_06-16-20-193613_c_fe_bak_dw_19491uM_5nMPa.txt"
data5="priming_bak1_3rd_post_06-16-20-202908.txt"
data6="priming_bak1_post_06-16-20-174130_1st.txt"

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/ -r $data1 -n 164747 -s 164747_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/ -r $data2 -n 180916 -s 180916_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/ -r $data3 -n 190520 -s 190520_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/ -r $data4 -n 193613 -s 193613_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/ -r $data5 -n 202908 -s 202908_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/ -r $data6 -n 174130 -s 174130_names.txt -tr -pn 1
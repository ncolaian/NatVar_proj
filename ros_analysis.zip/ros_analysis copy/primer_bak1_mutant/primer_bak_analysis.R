#This script will analyze the 1949 priming data with bak1-4 mutants

#I have the ROS data before the addition of flg22, but there is not interesting outcomes.

library(ggplot2)
library(tidyr)
library(ggpubr)
library(agricolae)
library(egg)

exp3 <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/174130.auc_data.csv")
exp2 <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/202908.auc_data.csv")
exp1 <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/190520.auc_data.csv")

exp3$Experiment <- "3"
exp2$Experiment <- "2"
exp1$Experiment <- "1"

combined <- rbind(exp3, exp2, exp1)

combined$logauc <- log10(combined$AUC)
combined$Experiment <- factor(combined$Experiment)

ggplot(combined, aes(Name, AUC, color=Experiment))+
  geom_boxplot()

#Try an anova first
combined$Experiment <- factor(combined$Experiment)
anova_simple <- aov(logauc ~ Name + Experiment, data = combined)
interact_anova <- aov(logauc ~ Name * Experiment, data = combined)
anova(anova_simple, interact_anova)
#simple is better

tukey_test <- HSD.test(interact_anova, trt = "Name")
test <- tukey_test$groups
test$names <- row.names(test)

plot(tukey_test)

exp3 <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/174130.summary_info.csv")
exp2 <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/202908.summary_info.csv")
exp1 <- read.csv("/Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/primer_bak1_mutant/190520.summary_info.csv")

exp1$measurement <- exp1$measurement - min(exp1$measurement)
exp2$measurement <- exp2$measurement - min(exp2$measurement)
exp3$measurement <- exp3$measurement - min(exp3$measurement)

exp1$Name[exp1$Name == "1949-bak1"] <- "bak1-4_1uM1949+5nMPa22"


ggplot(exp3, aes(x=Time/60, y=measurement, color=Name))+
  geom_line(size=1.5)+
  geom_errorbar(aes(ymin=measurement-se, ymax=measurement+se))+
  ylab("Photocount")+
  xlab("Minutes")+
  theme(text = element_text(size=20))+
  labs(color='Peptide') +
  #scale_y_log10()+
  scale_color_brewer(palette = "Set1")+
  theme_classic()+
  scale_x_continuous(breaks=c(0,6,13,16,26,30,40,50,60))+
  scale_y_continuous(breaks=c(0,5000,10000,15000), limits = c(0,17000))+
  theme(legend.position = "none")
  
  
  ggplot(exp2, aes(x=Time/60, y=measurement, color=Name))+
  geom_line(size=1.5)+
  geom_errorbar(aes(ymin=measurement-se, ymax=measurement+se))+
  ylab("Photocount")+
  xlab("Minutes")+
  theme(text = element_text(size=20))+
  labs(color='Peptide') +
  #scale_y_log10()+
  scale_color_brewer(palette = "Set1")+
  theme_classic()+
  scale_x_continuous(breaks=c(0,6,13,16,26,30,40,50,60))+
  scale_y_continuous(breaks=c(0,5000,10000,15000), limits = c(0,17000))+
  theme(legend.position = "none")
  
  ggplot(exp1, aes(x=Time/60, y=measurement, color=Name))+
  geom_line(size=1.5)+
  geom_errorbar(aes(ymin=measurement-se, ymax=measurement+se))+
  ylab("Photocount")+
  xlab("Minutes")+
  theme(text = element_text(size=20),
        legend.position = "none")+
  labs(color='Peptide') +
  #scale_y_log10()+
  scale_color_brewer(palette = "Set1")+
  theme_classic()+
  scale_x_continuous(breaks=c(0,6,13,16,26,30,40,50,60))+
  scale_y_continuous(breaks=c(0,5000,10000,15000), limits = c(0,17000))

#I wanna plot the same thing but without the 1uM data

exclude <- c("DW+1uM_elf18", "DW+1uM_Pta")

ggplot(exp3[!(exp3$Name %in% exclude),], aes(x=Time/60, y=measurement, color=Name))+
  geom_line(size=1.5)+
  geom_errorbar(aes(ymin=measurement-se, ymax=measurement+se))+
  ylab("Photocount")+
  xlab("Minutes")+
  theme(text = element_text(size=20))+
  labs(color='Peptide') +
  #scale_y_log10()+
  scale_color_brewer(palette = "Set1")+
  theme_classic()+
  scale_x_continuous(breaks=c(0,6,13,16,26,30,40,50,60))+
  scale_y_continuous(breaks=c(0,5000,10000), limits = c(0,10000))+
  theme(legend.position = "none")+
  
  
  ggplot(exp2[!(exp2$Name %in% exclude),], aes(x=Time/60, y=measurement, color=Name))+
  geom_line(size=1.5)+
  geom_errorbar(aes(ymin=measurement-se, ymax=measurement+se))+
  ylab("Photocount")+
  xlab("Minutes")+
  theme(text = element_text(size=20))+
  labs(color='Peptide') +
  #scale_y_log10()+
  scale_color_brewer(palette = "Set1")+
  theme_classic()+
  scale_x_continuous(breaks=c(0,6,13,16,26,30,40,50,60))+
  scale_y_continuous(breaks=c(0,5000,10000), limits = c(0,10000))+
  theme(legend.position = "none")+
  
  ggplot(exp1[!(exp1$Name %in% exclude),], aes(x=Time/60, y=measurement, color=Name))+
  geom_line(size=1.5)+
  geom_errorbar(aes(ymin=measurement-se, ymax=measurement+se))+
  ylab("Photocount")+
  xlab("Minutes")+
  theme(text = element_text(size=20),
        legend.position = "none")+
  labs(color='Peptide') +
  #scale_y_log10()+
  scale_color_brewer(palette = "Set1")+
  theme_classic()+
  scale_x_continuous(breaks=c(0,6,13,16,26,30,40,50,60))+
  scale_y_continuous(breaks=c(0,5000,10000), limits = c(0,10000))

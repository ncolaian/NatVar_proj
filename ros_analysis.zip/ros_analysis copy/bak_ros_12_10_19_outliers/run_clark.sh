data1="bak_exp_12-07-19-163353_pa_col_fe_14_15_1857_col_fe_14_15.txt"
data2="bak_exp_12-07-19-180956_pa_col_fe_14_15_1471_col_fe_14_15.txt"
data3="bak_exp_12-07-19-193547_pa_col_fe_14_15_1391_col_fe_14_15.txt"
data4="bak_exp_12-10-19-123132_pa_1391_col_fe_14_15.txt"
data5="bak_exp_12-10-19-134034_pa_1857_col_fe_14_15.txt"
data6="bak_exp_12-10-19-162029_pa_1471_col_fe_14_15.txt"
data7="bak_exp_12-11-19-134023_pa_1857_col_fe_14_15.txt"
data8="bak_exp_12-11-19-150756_pa_1471_col_fe_14_15.txt"
data9="outlier_02-26-20-130527_col_fe_4_5_pa_1391.txt"
data10="outlier_02-26-20-144149_col_fe_4_5_pa_1391.txt"
data11="outlier_02-27-20-132928_col_fe_4_5_pa_1471.txt"
data12="outlier_02-27-20-150428_col_fe_4_5_pa_1857.txt"

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data1 -n 163353 -s 163353_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data2 -n 180956 -s 180956_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data3 -n 193547 -s 193547_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data4 -n 123132 -s 123132_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data5 -n 134034 -s 134034_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data6 -n 162029 -s 162029_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data7 -n 134023 -s 134023_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data8 -n 150756 -s 150756_names.txt -tr -pn 1


perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data9 -n 130527 -s 130527_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data10 -n 144149 -s 144149_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data11 -n 132928 -s 132928_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/bak_ros_12_10_19/ -r $data12 -n 150428 -s 150428_names.txt -tr -pn 1
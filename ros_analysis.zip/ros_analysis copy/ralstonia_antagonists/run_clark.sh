data1="antag_09-03-20-155939_5001_5002_5003_5004_5005_5007_pa20_m.txt"
data2="antag_post1_09-03-20-172403_5nMPta22.txt"
data3="antag_post2_09-03-20-190325_5nMPta22.txt"
data4="antag_post3_09-03-20-201659_5nMPta22.txt"
data5="antag_post4_09-04-20-135029_5nMPta22.txt"
data6="antag_pre2_09-03-20-174925_5001_5002_5003_5004_5005_m_pa20_5007.txt"
data7="antag_pre3_09-03-20-192352_5001_5002_5003_5004_5005_m_pa20_5007.txt"
data8="antag_pre4_09-04-20-121332_5001_5002_5003_5004_5005_m_pa20_5007.txt"

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/ralstonia_antagonists/ -r $data1 -n 155939 -s 155939_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/ralstonia_antagonists/ -r $data2 -n 172403 -s 172403_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/ralstonia_antagonists/ -r $data3 -n 190325 -s 190325_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/ralstonia_antagonists/ -r $data4 -n 201659 -s 201659_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/ralstonia_antagonists/ -r $data5 -n 135029 -s 135029_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/ralstonia_antagonists/ -r $data6 -n 174925 -s 174925_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/ralstonia_antagonists/ -r $data7 -n 192352 -s 192352_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/nat_variants_proj/ros_analysis/ralstonia_antagonists/ -r $data8 -n 121332 -s 121332_names.txt -tr -pn 1
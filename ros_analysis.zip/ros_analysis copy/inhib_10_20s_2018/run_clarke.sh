data1="data_10-22-18-122122_pta_ptada_470_218_255_340_1195_1877.txt"
data2="data_10-22-18-132441_pta_ptada_pa_pa20_361_289_387_321.txt"
data3="data_10-22-18-175002_pta_ptada_1186_1042_1943_306_255_1635.txt"
data4="data_10-24-18-104953_pta_ptada_pa_pa20_118_373_445_457.txt"
data5="data_10-24-18-114842_pta_ptada_295_362_236_133_289_236.txt"
data6="data_10-24-18-124729_pta_ptada_1186_359_470_397_83_336.txt"
data7="data_10-24-18-152001_pta_ptada_1042_154_1787_133_1877_1477.txt"
data8="data_10-25-18-114504_pta_ptada_dw_pa20_218_362_435_99.txt"
data9="data_10-25-18-125358_pta_ptada_1477_17_340_295_361_306.txt"
data10="data_10-26-18-115607_pta_ptada_pa_pa20_445_99_83_1952.txt"
data11="data_10-26-18-125236_pta_ptada_397_373_1635_468_1090_1128.txt"
data12="data_10-26-18-135637_pta_ptada_467_154_94_1983_1391_1195.txt"
data13="data_10-26-18-163553_pta_ptada_359_94_467_1128_118_435.txt"
data14="data_10-29-18-111538_pta_ptada_pa_pa20_204_321_1787_253.txt"
data15="data_10-29-18-121934_pta_ptada_1943_457_1952_336_1843_1983.txt "
data16="data_10-29-18-134228_pta_ptada_1042_253_387_468_1128_1877.txt"
data17="data_10-22-18-160326_pta_ptada_306_1391_204_1090_17_1843.txt"

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data17 -n 160326 -s 160326_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data1 -n 122122 -s 122122_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data2 -n 132441 -s 132441_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data3 -n 175002 -s 175002_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data4 -n 104953 -s 104953_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data5 -n 114842 -s 114842_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data6 -n 124729 -s 124729_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data7 -n 152001 -s 152001_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data8 -n 114504 -s 114504_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data9 -n 125358 -s 125358_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data10 -n 115607 -s 115607_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data11 -n 125236 -s 125236_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data12 -n 135637 -s 135637_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data13 -n 163553 -s 163553_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data14 -n 111538 -s 111538_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data15 -n 121934 -s 121934_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/inhib_10_20s_2018/ -r $data16 -n 134228 -s 134228_names.txt -tr -pn 1

data1="antagonist_03-20-19-132356_0-0_10-0_10-10_10-50_10-100_3-30bad_3-0.txt"
data2="1186_antag_06-07-19-173617_1nm_1nm1_1nm3_1nm10_1nm100_1nm500_1um1_1umcalc.txt"

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/antagonist_pa20_1186/ -r $data1 -n 132356 -s 132356_names.txt -tr -pn 1

perl /Users/nicholascolaianni/Documents/dangl_lab/clark_matlab_code/clark_runner.pl -o /Users/nicholascolaianni/Documents/dangl_lab/ros_analysis/antagonist_pa20_1186/ -r $data2 -n 173617 -s 173617_names.txt -tr -pn 1

